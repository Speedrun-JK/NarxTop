const STORAGE_KEY = "arz_products";

function getProducts() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function normalize(text) {
  return (text || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeKey(text) {
  return (text || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const container = document.getElementById("products");
const searchInput = document.getElementById("search");
const categoryButtons = document.querySelectorAll(".categories button");
const minPriceInput = document.getElementById("min-price");
const maxPriceInput = document.getElementById("max-price");
const applyFilterBtn = document.getElementById("apply-filter");
const resetFilterBtn = document.getElementById("reset-filter");
const hotDealsBox = document.getElementById("hot-deals");

let selectedCategory = "all";
let products = getProducts();

function getFilteredProducts(list) {
  let filtered = list.filter(p => selectedCategory === "all" || p.category === selectedCategory);

  const searchValue = normalize(searchInput.value);
  if (searchValue) {
    filtered = filtered.filter(p => normalize(p.name).includes(searchValue));
  }

  const minPrice = minPriceInput.value ? Number(minPriceInput.value) : 0;
  const maxPrice = maxPriceInput.value ? Number(maxPriceInput.value) : Infinity;
  filtered = filtered.filter(p => Number(p.price) >= minPrice && Number(p.price) <= maxPrice);

  return filtered;
}

function renderHotDeals(list) {
  const hot = list
    .filter(p => p.hotDeal && p.oldPrice && Number(p.oldPrice) > Number(p.price))
    .map(p => {
      const oldP = Number(p.oldPrice);
      const newP = Number(p.price);
      const saveAmount = oldP - newP;
      const savePercent = Math.round((saveAmount / oldP) * 100);
      return { ...p, saveAmount, savePercent };
    })
    .sort((a, b) => b.saveAmount - a.saveAmount);

  hotDealsBox.innerHTML = "";

  if (hot.length === 0) {
    hotDealsBox.innerHTML = `<div class="hot-card">Hozircha hot deal yo'q.</div>`;
    return;
  }

  hot.forEach(p => {
    hotDealsBox.innerHTML += `
      <div class="hot-card">
        <strong>${p.name}</strong> - ${p.store}
        <div>Eski narx: ${Number(p.oldPrice).toLocaleString()} so'm</div>
        <div class="price">Yangi narx: ${Number(p.price).toLocaleString()} so'm</div>
        <div class="hot-savings">Tejaysiz: ${p.saveAmount.toLocaleString()} so'm (${p.savePercent}%)</div>
      </div>
    `;
  });
}

function renderProducts(list) {
  container.innerHTML = "";

  if (list.length === 0) {
    container.innerHTML = `<div class="product-card">Mahsulot topilmadi.</div>`;
    return;
  }

  const grouped = {};
  list.forEach(p => {
    const key = normalizeKey(p.name);
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(p);
  });

  Object.keys(grouped).forEach(key => {
    const items = grouped[key].sort((a, b) => Number(a.price) - Number(b.price));
    const cheapest = Number(items[0].price);
    const productImage = items.find(item => item.image)?.image || "";

    const card = document.createElement("div");
    card.className = "product-card";

    const body = document.createElement("div");
    body.className = "product-body";

    const info = document.createElement("div");
    info.className = "product-info";

    const title = document.createElement("div");
    title.className = "product-title";
    title.innerHTML = `<h3>${items[0].name}</h3><span>${items[0].category}</span>`;

    info.appendChild(title);

    items.forEach(p => {
      const row = document.createElement("div");
      row.className = "store-row";
      if (Number(p.price) === cheapest) row.classList.add("best");
      row.innerHTML = `
        <span class="store-name">${p.store}</span>
        <span class="price">${Number(p.price).toLocaleString()} so'm</span>
      `;
    info.appendChild(row);
  });

    if (productImage) {
      const img = document.createElement("img");
      img.className = "product-image";
      img.src = productImage;
      img.alt = items[0].name;
      body.appendChild(info);
      body.appendChild(img);
    } else {
      body.appendChild(info);
    }

    card.appendChild(body);

    container.appendChild(card);
  });
}

function rerenderAll() {
  products = getProducts();
  const filtered = getFilteredProducts(products);
  renderHotDeals(filtered);
  renderProducts(filtered);
}

categoryButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    categoryButtons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedCategory = btn.dataset.category;
    rerenderAll();
  });
});

searchInput.addEventListener("input", rerenderAll);
applyFilterBtn.addEventListener("click", rerenderAll);

resetFilterBtn.addEventListener("click", () => {
  minPriceInput.value = "";
  maxPriceInput.value = "";
  searchInput.value = "";
  selectedCategory = "all";
  categoryButtons.forEach(b => b.classList.remove("active"));
  document.querySelector('.categories button[data-category="all"]').classList.add("active");
  rerenderAll();
});

window.addEventListener("storage", (e) => {
  if (e.key === STORAGE_KEY) rerenderAll();
});

window.addEventListener("pageshow", rerenderAll);
window.addEventListener("focus", rerenderAll);

rerenderAll();
