const STORAGE_KEY = "arz_products";
const ADMIN_PASSWORD = "2010";
const ADMIN_AUTH_KEY = "arz_admin_auth";

function normalizeKey(text) {
  return (text || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getProducts() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function setProducts(products) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}

const nameInput = document.getElementById("name");
const categoryInput = document.getElementById("category");
const storeInput = document.getElementById("store");
const priceInput = document.getElementById("price");
const imageInput = document.getElementById("image");
const imagePreview = document.getElementById("imagePreview");
const hotDealInput = document.getElementById("hotDeal");
const oldPriceWrap = document.getElementById("oldPriceWrap");
const oldPriceInput = document.getElementById("oldPrice");
const editIndexInput = document.getElementById("editIndex");
const list = document.getElementById("list");
const saveBtn = document.getElementById("save-btn");
const clearBtn = document.getElementById("clear-btn");
const status = document.getElementById("status");

let currentImageData = "";
const MAX_IMAGE_SIZE = 900;
const IMAGE_QUALITY = 0.72;

function requireAdmin() {
  if (sessionStorage.getItem(ADMIN_AUTH_KEY) === "ok") return true;

  const input = prompt("Admin parolni kiriting:");
  if (input === ADMIN_PASSWORD) {
    sessionStorage.setItem(ADMIN_AUTH_KEY, "ok");
    return true;
  }

  window.location.href = "index.html";
  return false;
}

function setStatus(message, type) {
  status.textContent = message;
  status.dataset.type = type || "info";
}

function setImagePreview(src) {
  if (src) {
    imagePreview.src = src;
    imagePreview.style.display = "block";
  } else {
    imagePreview.removeAttribute("src");
    imagePreview.style.display = "none";
  }
}

function clearForm() {
  nameInput.value = "";
  priceInput.value = "";
  hotDealInput.checked = false;
  oldPriceInput.value = "";
  oldPriceWrap.style.display = "none";
  editIndexInput.value = "";
  imageInput.value = "";
  currentImageData = "";
  setImagePreview("");
  setStatus("Form tozalandi.", "info");
}

function renderList() {
  const products = getProducts();
  list.innerHTML = "";

  if (products.length === 0) {
    list.innerHTML = `<div class="product-row">Hozircha mahsulot yo'q.</div>`;
    return;
  }

  const grouped = {};
  products.forEach((p, i) => {
    const key = normalizeKey(p.name);
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push({ ...p, _index: i });
  });

  Object.keys(grouped).forEach(key => {
    const items = grouped[key];
    const groupName = items[0].name;

    const groupHeader = document.createElement("div");
    groupHeader.className = "product-row group-header";
    const groupImage = items.find(item => item.image)?.image || "";
    groupHeader.innerHTML = `
      <div class="group-title">
        ${groupImage ? `<img class="group-image" src="${groupImage}" alt="${groupName}">` : ""}
        <strong>${groupName}</strong>
      </div>
    `;
    list.appendChild(groupHeader);

    items.forEach(p => {
      const row = document.createElement("div");
      row.className = "product-row";
      row.innerHTML = `
        <div>
          <div>${p.category} | ${p.store}</div>
          <div>Narx: ${Number(p.price).toLocaleString()} so'm</div>
          ${p.hotDeal ? `<div>Eski: ${Number(p.oldPrice).toLocaleString()} so'm</div>` : ""}
        </div>
        <div class="actions">
          <button type="button" onclick="editProduct(${p._index})">Edit</button>
          <button type="button" class="secondary" onclick="deleteProduct(${p._index})">Delete</button>
        </div>
      `;
      list.appendChild(row);
    });
  });
}

function saveProduct() {
  const products = getProducts();
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);

  if (!name || !price) {
    setStatus("Mahsulot nomi va narxini kiriting!", "error");
    return;
  }

  const product = {
    name,
    category: categoryInput.value,
    store: storeInput.value,
    price,
    hotDeal: hotDealInput.checked,
    image: currentImageData
  };

  if (product.hotDeal) {
    const oldPrice = Number(oldPriceInput.value);
    if (!oldPrice || oldPrice <= price) {
      setStatus("Eski narx yangi narxdan katta bo'lsin.", "error");
      return;
    }
    product.oldPrice = oldPrice;
  }

  const editIndex = editIndexInput.value;
  if (editIndex === "") {
    products.push(product);
  } else {
    products[Number(editIndex)] = product;
    editIndexInput.value = "";
  }

  setProducts(products);
  renderList();
  clearForm();
  setStatus("Saqlandi!", "success");
}

function editProduct(index) {
  const products = getProducts();
  const p = products[index];
  if (!p) return;

  nameInput.value = p.name;
  categoryInput.value = p.category;
  storeInput.value = p.store;
  priceInput.value = p.price;
  hotDealInput.checked = !!p.hotDeal;
  oldPriceWrap.style.display = p.hotDeal ? "block" : "none";
  oldPriceInput.value = p.oldPrice || "";
  editIndexInput.value = index;
  currentImageData = p.image || "";
  imageInput.value = "";
  setImagePreview(currentImageData);
  setStatus("Tahrirlash rejimi.", "info");
}

function deleteProduct(index) {
  const products = getProducts();
  if (!products[index]) return;
  products.splice(index, 1);
  setProducts(products);
  renderList();
  setStatus("O'chirildi.", "success");
}

hotDealInput.addEventListener("change", () => {
  oldPriceWrap.style.display = hotDealInput.checked ? "block" : "none";
});

imageInput.addEventListener("change", () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) {
    currentImageData = "";
    setImagePreview("");
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(MAX_IMAGE_SIZE / img.width, MAX_IMAGE_SIZE / img.height, 1);
      const width = Math.round(img.width * scale);
      const height = Math.round(img.height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      currentImageData = canvas.toDataURL("image/jpeg", IMAGE_QUALITY);
      setImagePreview(currentImageData);
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});

if (requireAdmin()) {
  saveBtn.addEventListener("click", saveProduct);
  clearBtn.addEventListener("click", clearForm);

  renderList();
  setStatus("Admin tayyor.", "info");
}
